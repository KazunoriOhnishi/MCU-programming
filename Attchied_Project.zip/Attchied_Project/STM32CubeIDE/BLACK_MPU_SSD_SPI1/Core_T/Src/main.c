/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h" // SSD1306用ライブラリ（導入を想定）
#include "ssd1306_fonts.h" // SSD1306用ライブラリ（導入を想定）
#include "stdio.h"   // sprintf用
#include "string.h"
#include "math.h"
#include <stdio.h>
#define PI  3.14159
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// MPU6500のレジストリ定義
#define MPU6500_CS_LOW()  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)
#define MPU6500_CS_HIGH() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
/* プロトタイプ宣言 */
void MPU6500_ReadSensors(int16_t *accel, int16_t *gyro);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 簡易 float → string 関数
void floatToStr(float value, char *buffer, int decimals) {
    int intPart = (int)value;   // 整数部
    float frac = value - (float)intPart;  // 小数部
    if (frac < 0) frac = -frac; // 負数対応

    int fracInt = (int)(frac * pow(10, decimals)); // 小数部を整数化
    sprintf(buffer, "%d.%0*d", intPart, decimals, fracInt);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  // 1. MPU6500のスリープ解除
  uint8_t pwr_mgmt_data[2] = {0x6B, 0x00}; // PWR_MGMT_1 レジストリに0を書き込む
  MPU6500_CS_LOW();
  HAL_SPI_Transmit(&hspi1, pwr_mgmt_data, 2, HAL_MAX_DELAY);
  MPU6500_CS_HIGH();
  HAL_Delay(100);

  int16_t accel[3], gyro[3];

  // 2. SSD1306の初期化
  ssd1306_Init();
  ssd1306_Fill(Black);
  ssd1306_UpdateScreen();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

		 char display_buf[32];

	    // ─── 1. MPU6500からデータ取得 ───
//	    SPI1_SetPrescaler(SPI_BAUDRATEPRESCALER_64);          // 低速に設定
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);   // SSD1306のCSをOFF(High)
	    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,  GPIO_PIN_SET); // MPU6500のCSをON(Low)

	    MPU6500_ReadSensors(accel, gyro);                      // センサー読み出し

	    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4,  GPIO_PIN_RESET);   // MPU6500のCSをOFF(High)
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);

	    float Angle = -atan2(accel[1] , accel[2]) * (180.0f / PI);
	    float Gyro_x = -gyro[1] / 131.0f;

	    char buf1[32];
	    char buf2[32];

	    floatToStr(Angle, buf1, 2);
	    floatToStr(10.0*Gyro_x, buf2, 2);

	    ssd1306_Fill(Black);

	    ssd1306_SetCursor(0, 0);
	    ssd1306_WriteString("Angle:",Font_11x18, 1);
	    ssd1306_SetCursor(70, 0);
	    ssd1306_WriteString(buf1,Font_11x18, 1);

	    ssd1306_SetCursor(0, 20);
	    ssd1306_WriteString("Gyro:",Font_11x18, 1);
	    ssd1306_SetCursor(70, 20);
	    ssd1306_WriteString(buf2,Font_11x18, 1);

	    // ...文字描画の処理など...
	    ssd1306_UpdateScreen();                               // 画面へ送信

	    HAL_Delay(100);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(MPU_CS_GPIO_Port, MPU_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SSD_CS_GPIO_Port, SSD_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DC_Pin|RES_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : MPU_CS_Pin DC_Pin RES_Pin */
  GPIO_InitStruct.Pin = MPU_CS_Pin|DC_Pin|RES_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : SSD_CS_Pin */
  GPIO_InitStruct.Pin = SSD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SSD_CS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// MPU6500から14バイト（加速度・温度・ジャイロ）を一括で読み出す関数
void MPU6500_ReadSensors(int16_t *accel, int16_t *gyro) {
    uint8_t tx_addr = 0x3B | 0x80; // ACCEL_XOUT_H レジストリから読み出し
    uint8_t rx_buf[14];

    MPU6500_CS_LOW();
    HAL_SPI_Transmit(&hspi1, &tx_addr, 1, HAL_MAX_DELAY);
    HAL_SPI_Receive(&hspi1, rx_buf, 14, HAL_MAX_DELAY);
    MPU6500_CS_HIGH();

    // バイト結合 (Highバイト << 8 | Lowバイト)
    accel[0] = (int16_t)((rx_buf[0] << 8) | rx_buf[1]);  // Accel X
    accel[1] = (int16_t)((rx_buf[2] << 8) | rx_buf[3]);  // Accel Y
    accel[2] = (int16_t)((rx_buf[4] << 8) | rx_buf[5]);  // Accel Z
    // rx_buf[6],[7] は温度データ
    gyro[0]  = (int16_t)((rx_buf[8] << 8) | rx_buf[9]);  // Gyro X
    gyro[1]  = (int16_t)((rx_buf[10] << 8) | rx_buf[11]);// Gyro Y
    gyro[2]  = (int16_t)((rx_buf[12] << 8) | rx_buf[13]);// Gyro Z
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
