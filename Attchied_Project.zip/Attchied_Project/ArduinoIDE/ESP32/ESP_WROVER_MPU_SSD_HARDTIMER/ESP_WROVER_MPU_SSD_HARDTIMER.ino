// ESP_WROVER_MPU_SSD_HARDTIMER.ino
// MPUの出力をOLEDに表示
// ハードウェアタイマー使用

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <MPU6050.h>

// --- MPU6050 & OLED ---
MPU6050 mpu6050;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- センサ変数 ---
int16_t ax, ay, az, gx, gy, gz;
float Angle,Gyro_x;

// --- タイマ関連 ---
hw_timer_t *timer = NULL;
volatile bool sensorFlag = false;   // 割り込み→loopへ通知

#define LED_PIN 2
uint32_t startTime,elapsedTime;
bool LED = false;

// =========================
// タイマー割り込み
// =========================
void IRAM_ATTR onTimer() {
  sensorFlag = true;
}

// =========================
void setup()
{
    Wire.begin();
    Serial.begin(115200);

    if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
        Serial.println("SSD1306 connection failed");
        while (1);
    }
    display.clearDisplay();

    mpu6050.initialize();

    pinMode(LED_PIN, OUTPUT);

    // =========================
    // ハードウェアタイマー設定
    // =========================
    timer = timerBegin(1000000); // 1MHzタイマー（1us単位）
    timerAttachInterrupt(timer, &onTimer);
    timerAlarm(timer, 10000, true, 0); // 10ms周期

    startTime = micros();
}

// =========================
void loop()
{
    // ===== 10ms周期処理 =====
    if (sensorFlag) {
        sensorFlag = false;

        // MPU取得
        mpu6050.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
        Angle = atan2(ay, az) * 180 / PI;
        Gyro_x = -gx / 131;                   //加速度

        // OLED更新
        display.clearDisplay();
        display.setTextColor(WHITE);
        display.setTextSize(2);
        display.setCursor(0, 0);
        display.printf("Ang:%.1f", Angle);
        display.display();
    }

    // ===== 通常loop処理 =====
    digitalWrite(LED_PIN, LED);
    elapsedTime = micros() - startTime;
    elapsedTime = elapsedTime / 1000000.0;
    display.clearDisplay();
    display.setCursor(0, 32);
    display.print("Time ");
    display.println(elapsedTime);
    display.display();

    if ((elapsedTime) > 5.0) {
        LED = !LED;
        startTime = micros();
    }
}