// ESP__WROVER_Blink.ino
#define LED_PIN 2  // GPIO2 を LED 用に使う

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  delay(500);
  digitalWrite(LED_PIN, LOW);
  delay(500);
}
