// BLACK MPU SSD1306 HARDTimer.ino
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <MPU6050.h>

// --- MPU6050 & OLED ---
MPU6050 mpu6050;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- センサ変数 ---
int16_t ax, ay, az, gx, gy, gz;
float Angle;

// --- タイマ関連 ---
HardwareTimer *timer = nullptr;
volatile bool sensorFlag = false;   // 割り込み→loopへ通知

#define LED_PIN PC13
uint32_t startTime,elapsedTime;
bool LED = false;

// =========================
// タイマー割り込み
// =========================
void onTimer()
{
    sensorFlag = true;   // フラグのみ
}

// =========================
void setup()
{
    Wire.begin();
    Wire.setSDA(PB3);
    Wire.setSCL(PB10);

    Serial.begin(115200);

  Serial.begin(115200);
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println(F("SSD1306 disconnection"));
    for(;;); 
  }
    display.clearDisplay();

    mpu6050.initialize();
    delay(2);

    pinMode(LED_PIN, OUTPUT);

    // =========================
    // ハードウェアタイマー設定
    // =========================
    timer = new HardwareTimer(TIM1);   // 使用タイマ（環境に応じて変更）
    timer->setOverflow(10000, MICROSEC_FORMAT); // 10ms = 10000us
    timer->attachInterrupt(onTimer);
    timer->resume();

    startTime = micros();
}

// =========================
void loop()
{
    // ===== 10ms周期処理 =====
    if (sensorFlag) {
        sensorFlag = false;

        // MPU取得
        mpu6050.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
        Angle = atan2(ay, az) * 180 / PI;

        // OLED更新
        display.clearDisplay();
        display.setTextColor(WHITE);
        display.setTextSize(2);
        display.setCursor(0, 0);
        display.print("Angle ");
        display.println(Angle);
        display.display();
    }

    // ===== 通常loop処理 =====
    digitalWrite(LED_PIN, LED);
    elapsedTime = micros() - startTime;
    elapsedTime = elapsedTime / 1000000.0;
    display.clearDisplay();
    display.setCursor(0, 32);
    display.print("Time ");
    display.println(elapsedTime);
    display.display();

    if ((elapsedTime) > 5.0) {
        LED = !LED;
        startTime = micros();
    }
}