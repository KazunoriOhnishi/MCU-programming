// NANO MPU SSD.ino
// MPUの出力をOLEDに表示 
// 動作OK

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include <MPU6050.h>  //MPU6050ライブラリ

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define OLED_RESET -1
#define SCREEN_ADDRESS 0x78
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

//MPU6050オブジェクトをインスタンス化する。名前はmpu6050
MPU6050 mpu6050;
int16_t ax, ay, az, gx, gy, gz;  //三軸加速度、三軸ジャイロスコープ変数を定義

float Angle;     //角度変数
int16_t Gyro_x;  //角速度変数

void setup() {
  // I2Cバスに参加
  Wire.begin();
  //I2C2
//  Wire.setSCL(A5);
//  Wire.setSDA(A4);

  Serial.begin(115200);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 disconnection"));
    for (;;)
      ;
  }
  display.clearDisplay();  //初期化

  mpu6050.initialize();  //MPU6050を初期化
  delay(2);
}

void loop() {

  // IICを使用してMPU6050の六軸データを取得 ax ay az gx gy gz
  mpu6050.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  Angle = -atan2(ay, az) * (180 / PI);  //車両の傾き（度）
  Gyro_x = -gx / 131;                   //加速度

  Serial.print("30:");
  Serial.print(30);
  Serial.print(",");
  Serial.print("-30:");
  Serial.print(-30);
  Serial.print(",");

  Serial.print("Angle:");
  Serial.print(Angle);
  Serial.print(",");
  Serial.print("Gyro_x:");
  Serial.println(Gyro_x);

  delay(10);

  display.clearDisplay();

  display.setTextColor(WHITE);
  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Angle");
  display.println(Angle);
  display.setCursor(0, 30);
  display.print("Gyro_x");
  display.println(Gyro_x);
  display.display();
  // delay(2000);
}
