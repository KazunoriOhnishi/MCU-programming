// Uno_9250_1306_SPI_Hard.ino
// ライブラリ　MPU9250-master
// https://github.com/brianc118/MPU9250
// 

#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <MPU9250.h>

/* ==== ピン定義 ==== */
#define OLED_CS   10
#define OLED_DC   9
#define OLED_RST  8

#define MPU_CS    7
#define SPI_CLOCK 8000000  // 8MHz clock works.

int16_t ax, ay, az, gx, gy, gz;  //三軸加速度、三軸ジャイロスコープ変数を定義
float Angle;     //角度変数
float Gyro_x;  //角速度変数

/* ==== OLED ==== */
Adafruit_SSD1306 display(
  128, 64,
  &SPI,
  OLED_DC,
  OLED_RST,
  OLED_CS
);

/* ==== MPU9250 ==== */
//MPU9250 mpu(SPI, MPU_CS);
MPU9250 mpu(SPI_CLOCK, MPU_CS);

void setup() {
  Serial.begin(115200);
  delay(1000);

  SPI.begin();

  /* OLED */
  if (!display.begin(SSD1306_SWITCHCAPVCC)) {
    Serial.println("OLED failed");
    while (1);
  }

  /* MPU9250 */
	mpu.init(true);

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println("SPI OK");
  display.display();

  Serial.println("SPI MPU9250 OK");
}

void loop() {

	mpu.read_all();

//  mpu.read_mag();
//	mpu.read_acc();
//	mpu.read_gyro();

  ax=mpu.accel_data[0];
  ay=mpu.accel_data[1];
  az=mpu.accel_data[2];
  gx=mpu.gyro_data[0];

  Angle = -atan2(mpu.accel_data[1], mpu.accel_data[2]) * (180 / PI);  //車両の傾き（度）
  Gyro_x = 10*(-mpu.gyro_data[0] / 131);                   //加速度

  // シリアルプロッタ
  Serial.print("5:");
  Serial.print(5);
  Serial.print(",");
  Serial.print("-5:");
  Serial.print(-5);
  Serial.print(",");

  Serial.print("Angle:");
  Serial.print(Angle);
  Serial.print(",");
  Serial.print("  Gyro_x:");
  Serial.println(Gyro_x);

  // OLED
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Angle");
  display.println(Angle);
  display.setCursor(0, 30);
  display.print("Gyro_x");
  display.println(Gyro_x);
  display.display();

  delay(50);

}

