// ESP_WROVER_CAR_Transmitter.ino

#include <esp_now.h>
#include <WiFi.h>

#define X_AXIS_PIN 35
#define Y_AXIS_PIN 34
#define SWITCH_PIN 25

// 受信機のMACアドレス
uint8_t receiverMacAddress[] = {0x10,0x06,0x1C,0x40,0xB4,0x40};  //10:06:1C:40:B4:40

struct PacketData
{
  int16_t xAxisValue;
  int16_t yAxisValue;
  uint8_t switchPressed;
};
PacketData data;

byte xValue,yValue;
byte buttonPressed;

// この関数は、ジョイスティックの0～4095の値を0～254にマッピングするために使用されます。
// ジョイスティックの値の範囲は0～4095です。中心値は2047だがデッドバンドを作っている。
// この場合は1800～2200の範囲は中心値127にマッピングされます。
// リバースはモーターの回転方向を反転する。前後左右反転。

int mapAndAdjustJoystickDeadBandValues(int value, bool reverse)
{
  if (value >= 2200)
  {
    value = map(value, 2200, 4095, 127, 254);
  }
  else if (value <= 1800)
  {
    value = map(value, 1800, 0, 127, 0);  
  }
  else
  {
    value = 127;
  }

  if (reverse)
  {
    value = 254 - value;
  }
  return value;
}

// データ送信時のコールバック
// 第1引数の型を esp_now_send_info_t に変更
void OnDataSent(const esp_now_send_info_t *info, esp_now_send_status_t status) {
  // 送信先MACアドレスを使いたい場合は info->des_addr を参照します
  Serial.print("\r\nLast Packet Send Status:\t ");
  Serial.println(status);
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Message sent" : "Message failed");
}

void setup() 
{
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);

  // Configure joystick pins
  pinMode(X_AXIS_PIN, INPUT);
  pinMode(Y_AXIS_PIN, INPUT);
  pinMode(SWITCH_PIN, INPUT_PULLUP); // Internal pull-up resistor for button

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) 
  {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  else
  {
    Serial.println("Succes: Initialized ESP-NOW");
  }
  
/* esp_now_peer_info_t構造体には、主に以下の設定項目が含まれます。
-peer_addr: 相手デバイスの6バイトのMACアドレスを指定します。
-channel: 通信に使用するWi-Fiチャネル（1〜14）を指定します。
-encrypt: 通信を暗号化するかどうかを true / false で指定します。
-lmk: 暗号化する場合に使用するローカル・マスタ・キー（16バイト）を設定します。
-ifidx: 通信するWi-Fiインターフェース（StationモードかSoftAPモードか）を選択します。
*/
  esp_now_peer_info_t peerInfo; // 1. まず変数を宣言する
  memset(&peerInfo, 0, sizeof(peerInfo)); // 2. 構造体をゼロで初期化（Core 3.0で重要）
  memcpy(peerInfo.peer_addr, receiverMacAddress, 6);
  peerInfo.channel = 1;  
  peerInfo.encrypt = false;
  
  if (esp_now_add_peer(&peerInfo) != ESP_OK) // 3. 登録
  {
    Serial.println("Failed to add peer");
    return;
  }
  // 
  
  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK)
  {
    Serial.println("Failed to add peer");
    return;
  }
  else
  {
    Serial.println("Succes: Added peer");
  } 

  esp_now_register_send_cb(OnDataSent);

}
 
void loop() 
{
  xValue = analogRead(X_AXIS_PIN); // Range: 0-4095
  yValue = analogRead(Y_AXIS_PIN); // Range: 0-4095
  buttonPressed = digitalRead(SWITCH_PIN);
//
  data.xAxisValue = mapAndAdjustJoystickDeadBandValues(analogRead(X_AXIS_PIN), false);
  data.yAxisValue = mapAndAdjustJoystickDeadBandValues(analogRead(Y_AXIS_PIN), false);  
  data.switchPressed = buttonPressed; 

//  data.xAxisValue = xValue;
//  data.yAxisValue = yValue;  
//  data.switchPressed = buttonPressed; 

  Serial.printf("X=%d Y=%d SW=%d\n", data.xAxisValue, data.yAxisValue, data.switchPressed);

  esp_err_t result = esp_now_send(receiverMacAddress, (uint8_t *) &data, sizeof(data));
  if (result == ESP_OK) 
  {
    Serial.println("Sent with success");
  }
  else 
  {
    Serial.println("Error sending the data");
  }    
  
  if (data.switchPressed == true)
  {
    delay(500);
  }
  else
  {
    delay(50);
  }
}
