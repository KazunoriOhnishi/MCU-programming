//　STM UNO Blink.ino

void setup() {
  // 内蔵LEDピンを出力として初期化
  pinMode(PB13, OUTPUT);
}

void loop() {
  digitalWrite(PB13, HIGH);  // LEDを点灯
  delay(1000);               // 1秒待機
  digitalWrite(PB13, LOW);   // LEDを消灯
  delay(1000);               // 1秒待機
}