// WiFi_Stepper_DRV8825.ino
// MobaTools.hを使ってステッピングモーターを回す
// 速度変化　正転・反転

#include "MobaTools.h"

// ステッパーモーターの設定
const int dirX  = 5;
const int stepX = 2;
const int dirZ  = 7;
const int stepZ = 4;
const int enPin = 8;

// ステッパーモーターのインスタンス
// stepsPerRevはフルステップで200
// 1/8設定では1600にするとフルステップと同じ速で回る
const int stepsPerRev = 1600;
bool stepperRunning;
MoToStepper stepperL( stepsPerRev, STEPDIR );
MoToStepper stepperR( stepsPerRev, STEPDIR );

void setup() {

Serial.begin(115200); //シリアルモニタを開き、ボーレート設定
delay(1500);
Serial1.begin(9600);  //シリアル通信の初期化（HC-06用）
delay(1500);

// モーターの初期化
pinMode(enPin, INPUT);
digitalWrite(enPin, LOW); // 効いていない

pinMode(dirX,OUTPUT);
pinMode(stepX,OUTPUT);
pinMode(dirZ,OUTPUT);
pinMode(stepZ,OUTPUT);

stepperL.attach(stepX, dirX);
stepperR.attach(stepZ, dirZ);

// Configure each stepper
stepperL.setMaxSpeed(600);
stepperR.setMaxSpeed(600);
stepperL.setSpeed( 500 );
stepperR.setSpeed( 500 );

}

void loop() {

// スピードを変化させている
// 反転する
float speed;

speed = 100.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( 1 );
stepperR.rotate( -1 );
delay(5000);

speed = 300.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( 1 );
stepperR.rotate( -1 );
delay(5000);

speed = 500.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( 1 );
stepperR.rotate( -1 );
delay(5000);

speed = 300.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( 1 );
stepperR.rotate( -1 );
delay(5000);

speed = 100.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( 1 );
stepperR.rotate( -1 );
delay(5000);

speed = 0.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( 1 );
stepperR.rotate( -1 );
delay(5000);

speed = 100.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( -1 );
stepperR.rotate( 1 );
delay(5000);

speed = 0.0;Serial.println(speed);
stepperL.setSpeed( speed );
stepperR.setSpeed( speed );
stepperL.rotate( -1 );
stepperR.rotate( 1 );
delay(5000);

}