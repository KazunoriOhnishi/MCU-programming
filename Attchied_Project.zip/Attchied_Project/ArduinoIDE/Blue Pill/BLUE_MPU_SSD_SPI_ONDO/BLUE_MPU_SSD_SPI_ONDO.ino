// BLUE MPU_SSD SPI ONDO.ino
// ssd1306
// DH22 温度表示

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include <DHT22.h>
//define pin data
#define pinDATA PB11 // SDA, or almost any other I/O pin
DHT22 dht22(pinDATA); 

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

// Declaration for SSD1306 display connected using software SPI (default case):
#define OLED_MOSI   PB5
#define OLED_CLK    PB3

#define OLED_DC     PB6
#define OLED_CS     PB8
#define OLED_RESET  PB7
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT,
  OLED_MOSI, OLED_CLK, OLED_DC, OLED_RESET, OLED_CS);

void setup() {
  Serial.begin(115200);

  // SSD1306_SWITCHCAPVCC = generate display voltage from 3.3V internally
  if(!display.begin(SSD1306_SWITCHCAPVCC)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Don't proceed, loop forever
  }

  // Show initial display buffer contents on the screen --
  // the library initializes this with an Adafruit splash screen.
  display.display();
  delay(2000); // Pause for 2 seconds

  // Clear the buffer
  display.clearDisplay();

  // Draw a single pixel in white
  display.drawPixel(10, 10, SSD1306_WHITE);

  // Show the display buffer on the screen. You MUST call display() after
  // drawing commands to make them visible on screen!
  display.display();
  delay(2000);

}

void loop() {

// 計測
  Serial.println(dht22.debug()); //optionnal
  float t = dht22.getTemperature();
  float h = dht22.getHumidity();

//　OLEDに表示　漢字使えない
  display.clearDisplay();

  display.setTextColor(WHITE);
  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Shitudo ");
  display.println((h));
  display.setCursor(0, 40);
  display.print("Ondo ");
  display.println(t);
  display.display();

}

void testdrawline() {
  int16_t i;

  display.clearDisplay(); // Clear display buffer

}
