import time
from machine import I2C, Pin
import mpu6050
import SSD1306
import math

# 1. I2Cの初期化
i2c = I2C(2)

# 2. 各デバイスの初期化
PI = 3.14159
sensor = mpu6050.accel(i2c)
oled = SSD1306.SSD1306_I2C(128, 64, i2c, addr=0x3C)


def display_data():
    while True:
        try:
            # 3. センサーデータの取得
            values = sensor.get_values()
            accel_x = values["AcX"]
            accel_y = values["AcY"]
            accel_z = values["AcZ"]

            Angle = -math.atan2(accel_y,accel_z) * (180/ PI);

            # 4. ディスプレイへの描画
            oled.fill(0)
            oled.text("--- MPU6050 ---", 0, 0)
            oled.text("Angle: {:.2f}".format(Angle), 0, 20)
#           oled.text("X: {}".format(accel_x), 0, 20)
            oled.show()

        except Exception as e:
            print("Error:", e)

        time.sleep(1)

if __name__ == "__main__":
    print("Starting Main Program...")
    display_data()

